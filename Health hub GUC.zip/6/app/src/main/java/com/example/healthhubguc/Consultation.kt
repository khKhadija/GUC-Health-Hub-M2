package com.example.healthhubguc

data class Consultation(
    var id: String? = null,
    var description: String = "",
    var status: String = "",
    var patientId: String = "",
    var replyMessage: String? = null
)

